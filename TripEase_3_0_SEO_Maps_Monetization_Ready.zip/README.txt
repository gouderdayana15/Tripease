TripEase 2.0 mobile website
1. Open index.html to preview the site.
2. The booking buttons are placeholders.
3. Replace the affiliate() function destinations with your approved affiliate URLs after joining partner programmes.
4. Publish the folder on a static host such as your chosen hosting provider.
